FMA - NCI
----------------

- Reference UMLS-based mappings:
	Total mappings 3,024
	2,686 mappings "="
	338 mappings flagged with "?" (mapping involved in logical conflicts detected by Alcomo, LogMap and/or AML)

- FMA ontology (contains synonyms):
	- Whole ontology: 78,989 concepts
	- Small overlapping/module with NCI:  3,696 concepts (5%)

- NCI ontology (contains synonyms):
	- Whole ontology: 66,724 concepts
	- Small overlapping/module with FMA:  6,488 concepts (10%)




